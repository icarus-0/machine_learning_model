import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from LinearRegression import LinearRegression

dataset=pd.read_csv('Startups.csv')